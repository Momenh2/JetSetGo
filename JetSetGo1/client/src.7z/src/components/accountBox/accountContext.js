import { createContext } from "react";

export const AccountContext = createContext();
export default AccountContext