import AccountBox from "../../components/accountBox/index"
import "./Authentication.css";


const Authentication = () => {
    return(
       <div className="Authentication">
        <AccountBox/>
       </div>
    )
}

export default Authentication