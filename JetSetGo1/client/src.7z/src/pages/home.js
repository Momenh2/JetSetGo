import ItineraryManager from "./ItineraryManager";

const Home = () => {
    return(
        <div className="home">
             <h2>Home</h2>
             <ItineraryManager/>
        </div>
    )
}

export default Home;